﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;
using VehicleMasterFrontView.Models;

namespace VehicleMasterFrontView.Controllers
{
    public class VehicleMasterController : Controller
    {
        Uri BaseAddress = new Uri("https://localhost:7280");
        private readonly HttpClient _httpclient;

        public VehicleMasterController()
        {
            _httpclient = new HttpClient();
            _httpclient.BaseAddress = BaseAddress;
        }

        [HttpGet]
        public IActionResult Index()
        {
            List<VehicleMasterViewModel> listvehicle = new List<VehicleMasterViewModel>();
            HttpResponseMessage response = _httpclient.GetAsync(_httpclient.BaseAddress + "GetVehicleAllData").Result;

            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                var jsonResult = JsonConvert.DeserializeObject(data).ToString();
                listvehicle = JsonConvert.DeserializeObject<List<VehicleMasterViewModel>>(jsonResult, new JsonSerializerSettings
                {
                    NullValueHandling = NullValueHandling.Ignore
                });

            }

            return View(listvehicle);
        }


        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(VehicleMasterViewModel vehicleMasterViewModel)
        {
            try
            {
                string VehicleData = JsonConvert.SerializeObject(vehicleMasterViewModel);
                StringContent content = new StringContent(VehicleData, Encoding.UTF8, "application/json");
                HttpResponseMessage responce = _httpclient.PostAsync(_httpclient.BaseAddress + "api/Vehicle", content).Result;

                if (responce.IsSuccessStatusCode)
                {

                    TempData["SucessMessgae"] = "Vehicle Created";
                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {
                TempData["ErrorMessgae"] = ex.Message;
                return View();
            }
            return View();
        }
    }
}
