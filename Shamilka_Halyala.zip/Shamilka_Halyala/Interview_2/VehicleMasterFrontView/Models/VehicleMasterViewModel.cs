﻿using System.ComponentModel;

namespace VehicleMasterFrontView.Models
{
    public class VehicleMasterViewModel
    {

        public int VehicleID { get; set; }
        [DisplayName("Chassis Number")]
        public string ChassisNumber { get; set; }
        [DisplayName("EngineNumber")]
        public string EngineNumber { get; set; }
        [DisplayName("Model Name")]

        public string ModelName { get; set; }
        [DisplayName("Model ID")]
        public string ModelID { get; set; }
        [DisplayName("Date Of Manufacture")]
        public DateTime DateOfManufacture { get; set; }

    }
}
