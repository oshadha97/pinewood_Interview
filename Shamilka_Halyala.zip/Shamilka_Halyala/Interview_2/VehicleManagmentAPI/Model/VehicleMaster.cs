﻿namespace VehicleManagmentAPI.Model
{
    public class VehicleMaster
    {
        public int VehicleID { get; set; }
        public string ChassisNumber { get; set; }
        public string EngineNumber { get; set; }


        public string ModelName { get; set; }

        public string ModelID { get; set; }

        public string DateOfManufacture { get; set; }

    }
}
