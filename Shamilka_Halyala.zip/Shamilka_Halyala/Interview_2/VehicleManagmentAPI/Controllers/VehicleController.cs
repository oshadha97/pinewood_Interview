﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using VehicleManagmentAPI.Data;
using VehicleManagmentAPI.Model;

namespace VehicleManagmentAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VehicleController : ControllerBase
    {

        // Create New  Vehicle
        [HttpPost]
        public JsonResult CreateVehicle(VehicleMaster vehicleMaster)
        {

            // Call DB Class
            (new DALVehicleMaster()).CreateVehicleMaster(vehicleMaster.ChassisNumber, vehicleMaster.EngineNumber, vehicleMaster.ModelID, vehicleMaster.ModelName, vehicleMaster.DateOfManufacture);

            return new JsonResult(Ok(vehicleMaster));
        }

        [HttpGet("~/GetVehicle")]
        public JsonResult GetVehicle(string Chasinumber)
        {
            List<VehicleMaster> vehicleMaster = (new DALVehicleMaster()).VehicleMaster(Chasinumber);

            var jasonret = JsonSerializer.Serialize(vehicleMaster);
            return new JsonResult(jasonret);
        }

        [HttpGet("~/GetVehicleByVehicleID")]

        public JsonResult GetVehicleByVehicleID(string VehicleID)
        {
            List<VehicleMaster> vehicleMaster = (new DALVehicleMaster()).VehicleMasterByID(VehicleID);

            var jasonret = JsonSerializer.Serialize(vehicleMaster);
            return new JsonResult(jasonret);
        }

        [HttpGet("~/GetVehicleAllData")]

        public JsonResult GetVehicleAll()
        {
            List<VehicleMaster> vehicleMaster = (new DALVehicleMaster()).VehicleMasterAllData();

            var jasonret = JsonSerializer.Serialize(vehicleMaster);
            return new JsonResult(jasonret);
        }

    }





}
