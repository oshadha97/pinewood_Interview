﻿using System.Data;
using VehicleManagmentAPI.Model;

namespace VehicleManagmentAPI.Data
{
    public class DALVehicleMaster
    {

        /// <summary>
        /// Get Vhicle master by ChasiNumber
        /// </summary>
        /// <param name="ChasiNumber"></param>
        /// <returns></returns>
        public List<VehicleMaster> VehicleMaster(string ChasiNumber)
        {


            Dictionary<string, object> inputPara = new Dictionary<string, object>();
            inputPara.Add("@ChasiNumber", ChasiNumber);
            DataTable dtl = MSSQLDataUtility.SelectData("AVO_Yard_LeasingAsset", inputPara);



            List<VehicleMaster> DataList = new List<VehicleMaster>();

            DataList = (from DataRow row in dtl.Rows

                        select new VehicleMaster()
                        {
                            VehicleID = Convert.ToInt32(row["VehicleID"].ToString()),
                            ModelName = row["ChassisNumber"].ToString(),
                            ModelID = row["ModelID"].ToString(),
                            EngineNumber = row["EngineNumber"].ToString(),
                            ChassisNumber = row["ModelName"].ToString(),
                            //EngineNumber = row["make"].ToString(),
                            DateOfManufacture = Convert.ToString(row["DateOfManufacture"].ToString()),
                        }

                         ).ToList();



            return DataList;

        }

        /// <summary>
        /// Get Vehicle Master by Vehicle ID
        /// </summary>
        /// <param name="VehicleID"></param>
        /// <returns></returns>
        public List<VehicleMaster> VehicleMasterByID(string VehicleID)
        {


            Dictionary<string, object> inputPara = new Dictionary<string, object>();
            inputPara.Add("@VehicleID", VehicleID);
            DataTable dtl = MSSQLDataUtility.SelectData("get_VehicleMasterby_byVihicleID", inputPara);



            List<VehicleMaster> DataList = new List<VehicleMaster>();

            DataList = (from DataRow row in dtl.Rows

                        select new VehicleMaster()
                        {
                            VehicleID = Convert.ToInt32(row["VehicleID"].ToString()),
                            ModelName = row["ChassisNumber"].ToString(),
                            ModelID = row["ModelID"].ToString(),
                            EngineNumber = row["EngineNumber"].ToString(),
                            ChassisNumber = row["ModelName"].ToString(),
                            //EngineNumber = row["make"].ToString(),
                            DateOfManufacture = Convert.ToString(row["DateOfManufacture"].ToString()),
                        }

                         ).ToList();



            return DataList;

        }

        public DataTable CreateVehicleMaster(string ChassisNumber, string EngineNumber, string ModelID, string ModelName, string DateOfManufacture)
        {

            Dictionary<string, object> inputPara = new Dictionary<string, object>();
            Dictionary<string, object> outputParameter = new Dictionary<string, object>();
            Dictionary<string, object> outputParameterValues = new Dictionary<string, object>();
            DataTable aa = new DataTable();

            try
            {
                inputPara.Add("@ChassisNumber", ChassisNumber);
                inputPara.Add("@EngineNumber", EngineNumber);
                inputPara.Add("@ModelID", ModelID);
                inputPara.Add("@ModelName", ModelName);
                inputPara.Add("@DateOfManufacture", DateOfManufacture);
                MSSQLDataUtility.PopulateData("Insert_VehicleMaster", inputPara, outputParameter, outputParameterValues);


            }
            catch (Exception ex)
            {


            }





            return aa;

        }

        /// <summary>
        /// Get All Data
        /// </summary>
        /// <returns></returns>
        public List<VehicleMaster> VehicleMasterAllData()
        {


            Dictionary<string, object> inputPara = new Dictionary<string, object>();

            DataTable dtl = MSSQLDataUtility.SelectDataReturningDataSetNoInputs("get_VehicleMasterAllData").Tables[0];

            List<VehicleMaster> DataList = new List<VehicleMaster>();

            DataList = (from DataRow row in dtl.Rows

                        select new VehicleMaster()
                        {
                            VehicleID = Convert.ToInt32(row["VehicleID"].ToString()),
                            ModelName = row["ModelName"].ToString(),
                            ModelID = row["ModelID"].ToString(),
                            EngineNumber = row["EngineNumber"].ToString(),
                            ChassisNumber = row["ChassisNumber"].ToString(),
                            //EngineNumber = row["make"].ToString(),
                            DateOfManufacture = Convert.ToString(row["DateOfManufacture"].ToString()),
                        }

                         ).ToList();



            return DataList;

        }

    }
}
