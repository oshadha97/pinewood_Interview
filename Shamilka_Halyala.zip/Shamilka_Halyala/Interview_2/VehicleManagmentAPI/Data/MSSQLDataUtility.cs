﻿using System.Collections;
using System.Data;
using System.Data.SqlClient;

namespace VehicleManagmentAPI.Data
{
    public class MSSQLDataUtility
    {

        #region  live
        /// <summary>
        /// Open Data Connecton
        /// </summary>
        /// <returns></returns>
        private static SqlConnection OpenConnection()
        {
            SqlConnection conn = new SqlConnection();
            try
            {

                conn.ConnectionString =

                  "Data Source=.;" +
                  "Initial Catalog=inteview;" +
                  "Integrated Security=SSPI;";
                conn.Open();
                return conn;


            }
            catch (Exception ex)
            {
                conn = null;
            }

            return conn;

        }



        /// <summary>
        /// Close Connection
        /// </summary>
        /// <param name="_conn"></param>
        private static void closeConnection(SqlConnection _conn)
        {
            if (_conn.State == ConnectionState.Open)
                _conn.Close();
        }




        public static DataTable SelectData(string storedProcedureName, Dictionary<string, object> inputParameter)
        {
            DataSet dataSet = new DataSet();
            SqlDataAdapter adapter = new SqlDataAdapter();
            SqlCommand command = new SqlCommand();

            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = storedProcedureName;
            command.Connection = MSSQLDataUtility.OpenConnection();
            command.CommandTimeout = 0;
            adapter.SelectCommand = command;

            foreach (KeyValuePair<string, object> items in inputParameter)
            {
                SqlParameter parameter = new SqlParameter(items.Key, items.Value == null ? DBNull.Value : items.Value);
                parameter.Direction = ParameterDirection.Input;
                command.Parameters.Add(parameter);
            }
            adapter.Fill(dataSet);
            //SqlDataReader dataReader = command.ExecuteReader();
            MSSQLDataUtility.closeConnection(command.Connection);
            return dataSet.Tables[0]; //dataReader;
        }

        public static DataTable SelectData(DataTable dataSet, string storedProcedureName, Dictionary<string, object> inputParameter)
        {
            SqlDataAdapter adapter = new SqlDataAdapter();
            SqlCommand command = new SqlCommand();

            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = storedProcedureName;
            command.Connection = MSSQLDataUtility.OpenConnection();
            command.CommandTimeout = 0;
            adapter.SelectCommand = command;

            foreach (KeyValuePair<string, object> items in inputParameter)
            {
                SqlParameter parameter = new SqlParameter(items.Key, items.Value == null ? DBNull.Value : items.Value);
                parameter.Direction = ParameterDirection.Input;
                command.Parameters.Add(parameter);
            }
            adapter.Fill(dataSet);
            MSSQLDataUtility.closeConnection(command.Connection);
            return dataSet;
        }

        public static DataSet SelectDataReturningDataSet(string storedProcedureName, Dictionary<string, object> inputParameter)
        {
            DataSet dataSet = new DataSet();
            SqlDataAdapter adapter = new SqlDataAdapter();
            SqlCommand command = new SqlCommand();

            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = storedProcedureName;
            command.Connection = MSSQLDataUtility.OpenConnection();
            command.CommandTimeout = 0;
            adapter.SelectCommand = command;

            foreach (KeyValuePair<string, object> items in inputParameter)
            {
                SqlParameter parameter = new SqlParameter(items.Key, items.Value == null ? DBNull.Value : items.Value);
                parameter.Direction = ParameterDirection.Input;
                command.Parameters.Add(parameter);
            }
            adapter.Fill(dataSet);
            MSSQLDataUtility.closeConnection(command.Connection);
            return dataSet;
        }


        public static int PopulateData(string storedProcedureName, Dictionary<string, object> inputParameter, Dictionary<string, object> outputParameter, Dictionary<string, object> outputParameterValues)
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = storedProcedureName;
            command.CommandType = CommandType.StoredProcedure;
            command.Connection = MSSQLDataUtility.OpenConnection();

            foreach (KeyValuePair<string, object> items in inputParameter)
            {
                SqlParameter parameter = new SqlParameter(items.Key, items.Value == null ? DBNull.Value : items.Value);
                parameter.Direction = ParameterDirection.Input;
                command.Parameters.Add(parameter);
            }

            foreach (KeyValuePair<string, object> items in outputParameter)
            {
                ArrayList parameterItem = (ArrayList)items.Value;
                SqlParameter parameter = new SqlParameter(items.Key, (SqlDbType)parameterItem[0], (int)parameterItem[1]);
                parameter.Direction = ParameterDirection.Output;
                command.Parameters.Add(parameter);
            }

            int noOfRecord = command.ExecuteNonQuery();

            MSSQLDataUtility.closeConnection(command.Connection);

            foreach (SqlParameter parameter in command.Parameters)
            {
                if (parameter.Direction == ParameterDirection.Output)
                    outputParameterValues.Add(parameter.ParameterName, parameter.Value);
            }

            return noOfRecord;
        }


        /// <summary>
        /// Insert Data
        /// </summary>
        /// <param name="DBConnection"></param>
        /// <param name="storedProcedureName"></param>
        /// <param name="inputParameter"></param>
        /// <param name="outputParameter"></param>
        /// <param name="outputParameterValues"></param>
        /// <returns></returns>
        public static int Insert_Data(SqlConnection DBConnection, string storedProcedureName, Dictionary<string, object> inputParameter, Dictionary<string, object> outputParameter, Dictionary<string, object> outputParameterValues)
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = storedProcedureName;
            command.CommandType = CommandType.StoredProcedure;
            command.Connection = DBConnection;

            foreach (KeyValuePair<string, object> items in inputParameter)
            {
                SqlParameter parameter = new SqlParameter(items.Key, items.Value == null ? DBNull.Value : items.Value);
                parameter.Direction = ParameterDirection.Input;
                command.Parameters.Add(parameter);
            }

            foreach (KeyValuePair<string, object> items in outputParameter)
            {
                ArrayList parameterItem = (ArrayList)items.Value;
                SqlParameter parameter = new SqlParameter(items.Key, (SqlDbType)parameterItem[0], (int)parameterItem[1]);
                parameter.Direction = ParameterDirection.Output;
                command.Parameters.Add(parameter);
            }

            int noOfRecord = command.ExecuteNonQuery();

            MSSQLDataUtility.closeConnection(command.Connection);

            foreach (SqlParameter parameter in command.Parameters)
            {
                if (parameter.Direction == ParameterDirection.Output)
                    outputParameterValues.Add(parameter.ParameterName, parameter.Value);
            }

            return noOfRecord;
        }

        public static DataSet SelectDataReturningDataSetNoInputs(string storedProcedureName)
        {
            DataSet dataSet = new DataSet();
            SqlDataAdapter adapter = new SqlDataAdapter();
            SqlCommand command = new SqlCommand();

            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = storedProcedureName;
            command.Connection = MSSQLDataUtility.OpenConnection();
            command.CommandTimeout = 0;
            adapter.SelectCommand = command;

            adapter.Fill(dataSet);
            MSSQLDataUtility.closeConnection(command.Connection);
            return dataSet;
        }


        #endregion




    }
}
